# waste_segregation_using_cnn
A deep learning CNN model for automated waste segregation.
